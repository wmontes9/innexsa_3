<?php

namespace App\Http\Controllers;

use App\Semillero_Invest;
use Illuminate\Http\Request;

class SemilleroInvestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Semillero_Invest  $semillero_Invest
     * @return \Illuminate\Http\Response
     */
    public function show(Semillero_Invest $semillero_Invest)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Semillero_Invest  $semillero_Invest
     * @return \Illuminate\Http\Response
     */
    public function edit(Semillero_Invest $semillero_Invest)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Semillero_Invest  $semillero_Invest
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Semillero_Invest $semillero_Invest)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Semillero_Invest  $semillero_Invest
     * @return \Illuminate\Http\Response
     */
    public function destroy(Semillero_Invest $semillero_Invest)
    {
        //
    }
}
