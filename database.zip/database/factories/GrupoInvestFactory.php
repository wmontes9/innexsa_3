<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Grupo_Invest;
use Faker\Generator as Faker;

$factory->define(Grupo_Invest::class, function (Faker $faker) {
    return [
        //
    ];
});
