<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Sub_Linea_Semillero;
use Faker\Generator as Faker;

$factory->define(Sub_Linea_Semillero::class, function (Faker $faker) {
    return [
        //
    ];
});
