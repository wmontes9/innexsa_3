<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Semillero_Invest;
use Faker\Generator as Faker;

$factory->define(Semillero_Invest::class, function (Faker $faker) {
    return [
        //
    ];
});
