<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\solucion;
use Faker\Generator as Faker;

$factory->define(solucion::class, function (Faker $faker) {
    return [
        //
    ];
});
