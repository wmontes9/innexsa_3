<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Linea_Invest;
use Faker\Generator as Faker;

$factory->define(Linea_Invest::class, function (Faker $faker) {
    return [
        //
    ];
});
